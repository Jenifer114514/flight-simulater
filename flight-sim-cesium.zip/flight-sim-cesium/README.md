# Cesium Flight Sim — Phase 0

CesiumJS（1.146・CDN固定）の上で「実地形の上を飛ぶ」ための土台。
Phase 0 の範囲は **地形・画像・カメラ・HUD・出発地点切替** まで。飛行モデルは仮のキネマティック実装で、
Phase 1 で既存の翼素理論 `physics.js`（Three.js 版・無改造）に差し替える。

---

## 動かし方

```bash
cd flight-sim-cesium
python3 -m http.server 8100
# ブラウザで http://localhost:8100/ を開く
```

- `file://` で直接開くと Cesium の Web Worker が動かないため、**必ず HTTP 経由**で開く。
- インターネット接続が必要（Cesium 本体・アセットを jsDelivr から、地形・画像を Cesium ion から取得）。
- このワークスペース内のプレビュー（サンドボックス iframe）は**外部ネットワークが遮断される**ため動かない。
  その場合はページ内に「このプレビューでは CesiumJS を読み込めません」という案内カード（起動手順＋実行画面の
  スクリーンショット）が出る。実機で動かすにはローカルのブラウザで上記 URL を開くこと。

### スマホで動かす

PC でサーバーを立てて、同じ Wi-Fi のスマホから開くのが一番簡単。

```bash
# PC 側（--bind 0.0.0.0 が大事）
python3 -m http.server 8100 --bind 0.0.0.0

# PC の LAN IP を調べる
ipconfig getifaddr en0     # macOS
hostname -I                # Linux
ipconfig                   # Windows（IPv4 アドレス）
```

スマホのブラウザで `http://192.168.x.x:8100/` を開く（初回は PC のファイアウォール許可が必要な場合あり）。
外から使いたい場合は GitHub Pages / Netlify Drop などにフォルダをそのまま置けば、HTTPS の URL で開ける
（ion トークンは URL に載せず、設定パネルから入れるのが安全）。

スマホ向けの自動調整：

| 項目 | 内容 |
|---|---|
| 操作 | 画面ドラッグ＝ロール／ピッチ、右下の丸ボタン＝推力 ＋/−、リセット |
| 描画 | `resolutionScale = 0.85`、タイルキャッシュ 160、MSAA オフ、地形の詳細度を 1 段粗く |
| HUD | キーボード操作のヒントを隠し、`dvh` 対応（iOS のアドレスバー分を補正） |

### Cesium ion トークン

| 状態 | 地形 | 画像 |
|---|---|---|
| トークン無し | 楕円体（のっぺり） | Natural Earth II（全球の粗い衛星画像） |
| トークン有り | **Cesium World Terrain**（実地形） | Cesium World Imagery（高解像度） |

右上「設定 / 出発地点」→ トークンを貼り付けて保存。あるいは URL に付けて渡す：

```
http://localhost:8100/?token=eyJhbGci...
```

トークンは localStorage に保存される。HUD 左上のバッジが `World Terrain` になれば成功、`簡易地形` のままなら
取得に失敗している（コンソールに理由が出る）。

---

## 操作

| キー | 動作 |
|---|---|
| `W` / `S` | 機首上げ / 下げ |
| `A` / `D` | 左 / 右ロール（バンクで旋回） |
| `Q` / `E` | ヨー（ラダー相当・微弱） |
| `↑` / `↓` | 推力アップ / ダウン |
| `R` | その場で立て直し（リセット） |
| マウス／タッチドラッグ | 右へ倒す＝右ロール、下へ引く＝機首上げ |

出発地点プリセット：富士山 / グランドキャニオン / マッターホルン / 羽田空港 / ハワイ・オアフ。
任意地点は緯度・経度・高度（MSL）で指定可能（±85° の極域は非対応）。

---

## 画面の読み方

- **ALT** … 海面からの高度（MSL）
- **AGL** … 地表からの高さ（レーダーアルチメータ相当）。120 m を切るとオレンジ。`--` は地表高が未取得
- **LOC** … 現在の原点からの水平距離 / 原点リベース回数（20 km ごとに原点を切り直して座標精度を保つ）

---

## 構成

```
index.html        Cesium 1.146 を CDN から読む / HUD DOM / 設定パネル
css/hud.css       オーバーレイ UI（ダーク＋シアン、safe-area 対応）
js/geo.js         FlightSimGeo: ENU⇄ECEF 変換（east=x, north=-z, up=y）
js/main.js        Viewer 生成 / 地形・画像の適用 / 箱機体 / 追従カメラ / 仮飛行 / HUD / 入力
```

座標系は Three.js 版と揃えてある（`x=東, y=上, z=南`、前方向 = `-z`、ヘディングは北基準の時計回り）。
そのため Phase 1 では `physics.js` をそのまま流用できる。

デバッグ用フック（コンソールから）：

```js
__flightSimPhase0.ready                 // 起動完了フラグ
__flightSimPhase0.getState()            // 位置・姿勢・速度・AGL など
__flightSimPhase0.getViewer()           // Cesium.Viewer
__flightSimPhase0.spawnAt(139.7797, 35.5494, 900, 340)  // 緯度, 経度, 高度, 方位
```

---

## 検証済み（2026-10-21 / Chrome 131 + SwiftShader）

- トークン無しモードで起動 → コンソールエラー・404 なし、`簡易地形` バッジ表示
- 箱機体 5 パーツが毎フレーム追従（`CallbackProperty`）、どの姿勢でも画面中央付近に留まる
- キーボード（ピッチ／ロール／ヨー／推力）・マウスドラッグ・`R` リセットが動作
- プリセット／任意座標への移動、HUD 更新（LAT/LON/ALT/AGL/SPD/HDG）
- 20 km リベース、AGL 計測（0.25 秒間隔）
- オフライン時（CDN 遮断）: JavaScript 例外を出さず、案内カードに切り替わることを確認
- モバイル（iPhone 相当の 390×844 / タッチ）: タッチパッド表示・推力ボタン（60→92%）・ドラッグ操縦（ピッチ 7.9°/ロール 40.6°）・HUD 更新を確認

## 未検証・Phase 1 に送る項目

- **World Terrain / World Imagery の実取得**（トークンが必要なので未確認）
- 地表高の取得はまだ `globe.getHeight()`（ロード済みタイル限定・`undefined` を返すことあり）。
  設計メモの **GroundSampler（1 km セルキャッシュ + `sampleTerrainMostDetailed`）** は Phase 1 で実装する
- 接地・墜落判定（Phase 0 は地表 +6 m で押し戻すだけ）
- 翼素理論 `physics.js` への差し替え、滑走路・空港データ
