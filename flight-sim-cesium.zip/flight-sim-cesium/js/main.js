// Cesium Flight Sim — Phase 0
// 目的: 実地形（Cesium World Terrain）の上に機体を置き、カメラが追従することを確認する。
//       ※ 飛行モデルは Phase 0 用の仮実装（キネマティック）。Phase 1 で既存の翼素理論 physics.js に差し替える。
(function (global) {
  'use strict';

  var C = global.Cesium;

  // Cesium が読めていない（CDN 不達 / オフラインプレビュー）場合は何もせず案内に任せる
  if (!C) {
    if (global.__cesiumFail) global.__cesiumFail();
    else document.documentElement.classList.add('no-cesium');
    return;
  }

  var Geo = global.FlightSimGeo;
  if (!Geo) {
    console.error('[flight-sim] js/geo.js が読み込まれていません');
    return;
  }

  var PRESETS = [
    { id: 'fuji',       name: '富士山',         lon: 138.7274, lat: 35.3606, alt: 3200, hdg: 200 },
    { id: 'canyon',     name: 'グランドキャニオン', lon: -112.1129, lat: 36.1069, alt: 3500, hdg: 90 },
    { id: 'matterhorn', name: 'マッターホルン',    lon: 7.6586,   lat: 45.9763, alt: 4200, hdg: 250 },
    { id: 'haneda',     name: '羽田空港',        lon: 139.7797, lat: 35.5494, alt: 900,  hdg: 340 },
    { id: 'oahu',       name: 'ハワイ・オアフ',    lon: -158.1,   lat: 21.4,    alt: 2500, hdg: 180 }
  ];

  var DEFAULT = PRESETS[0];

  // 局所座標（x=東, y=高度MSL, z=南）。前方 = -z（北）
  var state = {
    x: 0, y: DEFAULT.alt, z: 0,
    hdg: C.Math.toRadians(DEFAULT.hdg),
    pitch: 0, roll: 0,
    speed: 62, throttle: 0.6,
    groundH: null,        // 現在地の地表高（MSL, メートル）
    agl: null,
    lon: DEFAULT.lon, lat: DEFAULT.lat, alt: DEFAULT.alt, hdgDeg: DEFAULT.hdg,
    terrainMode: 'simple', // 'simple' | 'world'
    rebases: 0
  };

  // タッチ端末（スマホ／タブレット）判定
  var IS_TOUCH = false;
  try {
    IS_TOUCH = global.matchMedia('(pointer: coarse)').matches ||
               /iPhone|iPad|iPod|Android/i.test(global.navigator.userAgent);
  } catch (e) {}
  state.isTouch = IS_TOUCH;

  var keys = Object.create(null);
  var drag = { active: false, pitch: 0, roll: 0, x: 0, y: 0, id: null };

  var viewer = null;
  var aircraftParts = [];
  var aircraftEcef = new C.Cartesian3();
  var attitudeEcef = new C.Quaternion();
  var groundClock = 0;
  var hudClock = 0;

  // スクラッチ（毎フレームの確保を避ける）
  var sM3 = new C.Matrix3();
  var sM4 = new C.Matrix4();
  var sV1 = new C.Cartesian3();
  var sV2 = new C.Cartesian3();
  var sCarto = new C.Cartographic();
  var sHpr = new C.HeadingPitchRoll();

  // ---------------------------------------------------------------
  // ユーティリティ
  // ---------------------------------------------------------------
  function $(id) { return document.getElementById(id); }
  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
  function log() {
    var args = Array.prototype.slice.call(arguments);
    args.unshift('[flight-sim]');
    console.log.apply(console, args);
  }

  function setLoadingText(main, sub) {
    var t = $('loading-text'); if (t && main !== undefined) t.textContent = main;
    var s = $('loading-sub');  if (s && sub !== undefined)  s.textContent = sub;
  }
  function hideLoading() {
    var el = $('loading');
    if (el) { el.classList.add('hidden'); setTimeout(function () { el.style.display = 'none'; }, 400); }
  }
  function showNotice(msg, isInfo) {
    var el = $('notice');
    if (!el) return;
    el.textContent = msg;
    el.classList.toggle('info', !!isInfo);
    el.classList.remove('hidden');
    clearTimeout(showNotice._t);
    showNotice._t = setTimeout(function () { el.classList.add('hidden'); }, 6000);
  }

  // ---------------------------------------------------------------
  // トークン
  // ---------------------------------------------------------------
  var TOKEN_KEY = 'cesiumIonToken';

  function readToken() {
    try {
      var q = new URLSearchParams(global.location.search).get('token');
      if (q) { localStorage.setItem(TOKEN_KEY, q); return q.trim(); }
      return (localStorage.getItem(TOKEN_KEY) || '').trim();
    } catch (e) { return ''; }
  }
  function writeToken(v) {
    try {
      if (v) localStorage.setItem(TOKEN_KEY, v.trim());
      else localStorage.removeItem(TOKEN_KEY);
    } catch (e) {}
  }

  // ---------------------------------------------------------------
  // Cesium 初期化
  // ---------------------------------------------------------------
  function createViewer() {
    viewer = new C.Viewer('cesiumContainer', {
      baseLayer: false,          // 画像は自前で追加（トークン無しでもエラーを出さない）
      scene3DOnly: true,
      baseLayerPicker: false,
      geocoder: false,
      homeButton: false,
      sceneModePicker: false,
      navigationHelpButton: false,
      animation: false,
      timeline: false,
      fullscreenButton: false,
      infoBox: false,
      selectionIndicator: false,
      shouldAnimate: true
    });

    var scene = viewer.scene;
    scene.globe.enableLighting = false;
    scene.globe.depthTestAgainstTerrain = true;
    scene.fog.enabled = true;
    scene.skyAtmosphere.show = true;
    scene.highDynamicRange = false;
    // 自前の操縦（カメラは毎フレーム設定）なので Cesium のカメラ操作は無効化
    scene.screenSpaceCameraController.enableInputs = false;

    scene.globe.maximumScreenSpaceError = IS_TOUCH ? 4 : 3;
    // モバイルはGPU負荷とメモリを抑える（解像度を少し落とし、タイルキャッシュを小さく）
    if (IS_TOUCH) {
      viewer.resolutionScale = 0.85;
      scene.globe.tileCacheSize = 160;
      scene.msaaSamples = 1;
    }

    // タイル取得の進捗をローディングに表示
    scene.globe.tileLoadProgressEvent.addEventListener(function (remaining) {
      if (remaining > 0) setLoadingText(undefined, 'タイル ' + remaining + ' 枚を読み込み中…');
    });

    return viewer;
  }

  function addNaturalEarth() {
    return C.TileMapServiceImageryProvider
      .fromUrl(C.buildModuleUrl('Assets/Textures/NaturalEarthII'))
      .then(function (provider) {
        viewer.imageryLayers.addImageryProvider(provider);
      })
      .catch(function (e) {
        console.warn('[flight-sim] NaturalEarthII failed', e);
      });
  }

  // 地形と画像を（再）適用する
  function applyTerrain() {
    var token = readToken();
    viewer.imageryLayers.removeAll();

    if (!token) {
      viewer.terrainProvider = new C.EllipsoidTerrainProvider();
      state.terrainMode = 'simple';
      state.groundH = 0;
      updateTerrainBadge();
      return addNaturalEarth();
    }

    C.Ion.defaultAccessToken = token;
    setLoadingText('地形を読み込み中…', 'Cesium World Terrain');

    return C.CesiumTerrainProvider
      .fromIonAssetId(1, { requestVertexNormals: true })
      .then(function (tp) {
        viewer.terrainProvider = tp;
        state.terrainMode = 'world';
        updateTerrainBadge();
        return C.createWorldImageryAsync()
          .then(function (img) { viewer.imageryLayers.addImageryProvider(img); })
          .catch(function (e) {
            console.warn('[flight-sim] world imagery failed', e);
            showNotice('画像タイルの取得に失敗しました（地形は有効）。', true);
            return addNaturalEarth();
          });
      })
      .catch(function (e) {
        console.warn('[flight-sim] World Terrain failed', e);
        showNotice('World Terrain を取得できませんでした。\nトークンの権限（Asset 1 へのアクセス）を確認してください。\n簡易地形モードで起動します。');
        viewer.terrainProvider = new C.EllipsoidTerrainProvider();
        state.terrainMode = 'simple';
        state.groundH = 0;
        updateTerrainBadge();
        return addNaturalEarth();
      });
  }

  function updateTerrainBadge() {
    var el = $('terrain-badge');
    if (!el) return;
    if (state.terrainMode === 'world') {
      el.textContent = 'World Terrain';
      el.classList.add('world');
    } else {
      el.textContent = '簡易地形';
      el.classList.remove('world');
    }
  }

  // ---------------------------------------------------------------
  // 機体（箱のプレースホルダ）
  // ---------------------------------------------------------------
  function makePart(offsets, dims, color) {
    // 位置・姿勢は毎フレーム変わるので CallbackProperty（isConstant=false）で参照させる。
    // 参照先のオブジェクトは updateAircraftFrame() がその場で書き換える。
    var world = new C.Cartesian3();
    var position = new C.CallbackProperty(function () { return world; }, false);
    var orientation = new C.CallbackProperty(function () { return attitudeEcef; }, false);
    viewer.entities.add({
      position: position,
      orientation: orientation,
      box: {
        dimensions: new C.Cartesian3(dims[0], dims[1], dims[2]),
        material: C.Color.fromCssColorString(color),
        outline: true,
        outlineColor: C.Color.fromCssColorString('#2a0d0d'),
        heightReference: C.HeightReference.NONE
      }
    });
    aircraftParts.push({
      offset: new C.Cartesian3(offsets[0], offsets[1], offsets[2]), // ENU: east, north, up
      world: world
    });
  }

  function buildPlaceholderAircraft() {
    // ENU オフセット（east, north, up）と寸法（east, north, up）
    makePart([0, 0, 0.05], [7.0, 1.15, 0.18], '#a82828');     // 主翼
    makePart([0, -0.1, 0], [0.72, 4.2, 0.72], '#cc3333');     // 胴体
    makePart([0, 2.45, -0.1], [0.5, 0.95, 0.5], '#cc3333');   // 機首
    makePart([0, -1.8, 0.12], [2.6, 0.7, 0.1], '#a82828');    // 水平尾翼
    makePart([0, -1.8, 0.55], [0.1, 0.85, 0.95], '#a82828');  // 垂直尾翼
  }

  // 機体の ECEF 位置・姿勢を更新
  function updateAircraftFrame() {
    Geo.localToEcef(state.x, state.y, state.z, aircraftEcef);

    sHpr.heading = state.hdg;
    sHpr.pitch = state.pitch;
    sHpr.roll = state.roll;
    C.Transforms.headingPitchRollQuaternion(
      aircraftEcef, sHpr, C.Ellipsoid.WGS84, C.Transforms.eastNorthUpToFixedFrame, attitudeEcef
    );

    // パーツ配置: 機体姿勢で ENU オフセットを回してから、機体位置の ENU フレームで加算
    var attitudeEnu = C.Quaternion.fromHeadingPitchRoll(sHpr);
    C.Matrix3.fromQuaternion(attitudeEnu, sM3);
    C.Transforms.eastNorthUpToFixedFrame(aircraftEcef, C.Ellipsoid.WGS84, sM4);

    for (var i = 0; i < aircraftParts.length; i++) {
      var p = aircraftParts[i];
      C.Matrix3.multiplyByVector(sM3, p.offset, sV1);
      C.Matrix4.multiplyByPoint(sM4, sV1, p.world);
    }
  }

  // ---------------------------------------------------------------
  // カメラ（機体の後方から追従）
  // ---------------------------------------------------------------
  // ENU（east, north, up）のベクトルを ECEF に回して返す小道具
  var sV3 = new C.Cartesian3();
  var sDir = new C.Cartesian3();
  var sUp = new C.Cartesian3();

  function updateCamera() {
    var back = 19.0;   // 機体の後方距離 (m)
    var upH = 3.4;     // 機体の上方距離 (m)

    var ch = Math.cos(state.hdg), sh = Math.sin(state.hdg);
    var cp = Math.cos(state.pitch), sp = Math.sin(state.pitch);

    // 機体基準の ENU 単位ベクトル
    var fwdE = sh * cp,  fwdN = ch * cp,  fwdU = sp;
    var upE = -sh * sp,  upN = -ch * sp,  upU = cp;
    var rgtE = ch,       rgtN = -sh,      rgtU = 0;

    // カメラ位置: 機体の後方 + 上方
    var camE = -fwdE * back + upE * upH;
    var camN = -fwdN * back + upN * upH;
    var camU = -fwdU * back + upU * upH;

    // 視線: 機体の少し前方を狙う（機体が画面中央やや下に来る）
    var aim = 16.0;
    var dirE = fwdE * aim - camE;
    var dirN = fwdN * aim - camN;
    var dirU = fwdU * aim - camU;

    // カメラの up は、機体のロールに半分だけ追従させる（水平線が半分傾く）
    var cr = Math.cos(state.roll), sr = Math.sin(state.roll);
    var rollUpE = upE * cr + rgtE * sr;
    var rollUpN = upN * cr + rgtN * sr;
    var rollUpU = upU * cr + rgtU * sr;
    var upOutE = upE * 0.45 + rollUpE * 0.55;
    var upOutN = upN * 0.45 + rollUpN * 0.55;
    var upOutU = upU * 0.45 + rollUpU * 0.55;

    C.Transforms.eastNorthUpToFixedFrame(aircraftEcef, C.Ellipsoid.WGS84, sM4);

    sV1.x = camE; sV1.y = camN; sV1.z = camU;          // ローカル座標でのカメラ位置
    C.Matrix4.multiplyByPoint(sM4, sV1, sV3);           // → ワールド位置

    sV2.x = dirE; sV2.y = dirN; sV2.z = dirU;
    C.Matrix4.multiplyByPointAsVector(sM4, sV2, sDir);
    C.Cartesian3.normalize(sDir, sDir);

    sV2.x = upOutE; sV2.y = upOutN; sV2.z = upOutU;
    C.Matrix4.multiplyByPointAsVector(sM4, sV2, sUp);
    C.Cartesian3.normalize(sUp, sUp);

    viewer.camera.setView({
      destination: sV3,
      orientation: { direction: sDir, up: sUp }
    });
  }


  // ---------------------------------------------------------------
  // 仮の飛行モデル（Phase 0）
  // ---------------------------------------------------------------
  function updateFlight(dt) {
    var pitchIn = ((keys['w'] ? 1 : 0) - (keys['s'] ? 1 : 0)) + drag.pitch;
    var rollIn = ((keys['d'] ? 1 : 0) - (keys['a'] ? 1 : 0)) + drag.roll;
    var yawIn = (keys['e'] ? 1 : 0) - (keys['q'] ? 1 : 0);
    var thrIn = (keys['arrowup'] ? 1 : 0) - (keys['arrowdown'] ? 1 : 0);
    pitchIn = clamp(pitchIn, -1, 1);
    rollIn = clamp(rollIn, -1, 1);

    state.pitch = clamp(state.pitch + pitchIn * 0.55 * dt, -1.15, 1.15);
    state.roll = clamp(state.roll + rollIn * 1.7 * dt, -1.45, 1.45);

    // バンクで旋回（協調旋回の簡易近似）
    state.hdg += (Math.sin(state.roll) * 0.85 + yawIn * 0.30) * dt;
    if (state.hdg > Math.PI) state.hdg -= Math.PI * 2;
    if (state.hdg < -Math.PI) state.hdg += Math.PI * 2;

    // 入力が無いときはゆるく水平へ
    if (Math.abs(pitchIn) < 0.01) state.pitch *= Math.pow(0.55, dt);
    if (Math.abs(rollIn) < 0.01) state.roll *= Math.pow(0.35, dt);

    // 推力と速度
    state.throttle = clamp(state.throttle + thrIn * dt * 0.55, 0, 1);
    var targetSpeed = 42 + state.throttle * 85;
    state.speed += (targetSpeed - state.speed) * Math.min(1, dt * 0.9);

    // 移動（前方 = 北 = -z）
    var horiz = state.speed * Math.cos(state.pitch);
    state.x += Math.sin(state.hdg) * horiz * dt;
    state.z -= Math.cos(state.hdg) * horiz * dt;
    state.y += state.speed * Math.sin(state.pitch) * dt;

    // 高度上限
    if (state.y > 12000) { state.y = 12000; if (state.pitch > 0) state.pitch = 0; }

    // 地面（Phase 0 は墜落させず、地表 +6m で押し戻す）
    if (state.groundH !== null && state.y < state.groundH + 6) {
      state.y = state.groundH + 6;
      if (state.pitch < 0) state.pitch = 0;
      state.roll *= Math.pow(0.2, dt);
    }

    // 原点リベース（局所座標の精度維持）: 20km 離れたら現在地を新しい原点にする
    if (Math.abs(state.x) > 20000 || Math.abs(state.z) > 20000) {
      var now = { lon: 0, lat: 0, height: 0 };
      Geo.ecefToLonLat(aircraftEcef, now);
      Geo.setOrigin(now.lon, now.lat);
      state.x = 0;
      state.z = 0;
      state.rebases++;
      log('rebase', state.rebases, now.lon.toFixed(4), now.lat.toFixed(4));
    }
  }

  // ---------------------------------------------------------------
  // 地表高・AGL（0.25秒ごと）
  // ---------------------------------------------------------------
  function probeGround() {
    if (state.terrainMode !== 'world') { state.groundH = 0; state.agl = state.y; return; }

    C.Cartographic.fromCartesian(aircraftEcef, C.Ellipsoid.WGS84, sCarto);
    var h = viewer.scene.globe.getHeight(sCarto);
    if (typeof h === 'number' && isFinite(h)) {
      state.groundH = h;
      state.agl = state.y - h;
    } else {
      // タイル未ロード時は undefined。値は保持し、AGL は不明表示
      state.agl = state.groundH === null ? null : state.y - state.groundH;
    }
  }

  // ---------------------------------------------------------------
  // HUD
  // ---------------------------------------------------------------
  function updateHud() {
    var ll = { lon: 0, lat: 0, height: 0 };
    Geo.ecefToLonLat(aircraftEcef, ll);
    state.lon = ll.lon; state.lat = ll.lat; state.alt = state.y;

    var set = function (id, text) { var el = $(id); if (el) el.textContent = text; };
    set('v-lat', ll.lat.toFixed(5) + '°');
    set('v-lon', ll.lon.toFixed(5) + '°');
    set('v-alt', Math.round(state.y).toLocaleString());
    set('v-agl', state.agl === null ? '--' : Math.round(state.agl).toLocaleString());
    set('v-spd', Math.round(state.speed));
    set('v-thr', String(Math.round(state.throttle * 100)));
    set('v-hdg', String(Math.round(((C.Math.toDegrees(state.hdg) % 360) + 360) % 360)).padStart(3, '0'));
    set('v-loc', (Math.hypot(state.x, state.z) / 1000).toFixed(1) + ' km / 再原点 ' + state.rebases);

    var aglEl = $('v-agl');
    if (aglEl) aglEl.style.color = (state.agl !== null && state.agl < 120) ? '#ff8a6a' : '';
  }

  // ---------------------------------------------------------------
  // ループ
  // ---------------------------------------------------------------
  var lastTime = 0;

  function tick(now) {
    var dt = lastTime ? (now - lastTime) / 1000 : 0.016;
    lastTime = now;
    dt = clamp(dt, 0, 0.05);

    updateFlight(dt);
    updateAircraftFrame();
    updateCamera();

    groundClock += dt;
    if (groundClock >= 0.25) { groundClock = 0; probeGround(); }

    hudClock += dt;
    if (hudClock >= 0.1) { hudClock = 0; updateHud(); }

    // 高度に応じて地形の詳細度を調整（低高度ほど高精細）
    var camH = viewer.camera.positionCartographic.height;
    if (IS_TOUCH) viewer.scene.globe.maximumScreenSpaceError = camH < 3000 ? 2.5 : 6.0;
    else viewer.scene.globe.maximumScreenSpaceError = camH < 3000 ? 1.5 : 4.0;

    requestAnimationFrame(tick);
  }

  // ---------------------------------------------------------------
  // 出発地点の設定
  // ---------------------------------------------------------------
  function spawnAt(lon, lat, alt, hdgDeg) {
    Geo.setOrigin(lon, lat);
    state.x = 0;
    state.z = 0;
    state.y = alt;
    state.hdg = C.Math.toRadians(hdgDeg || 0);
    state.pitch = 0;
    state.roll = 0;
    state.speed = 62;
    state.throttle = 0.6;
    state.groundH = null;
    state.agl = null;
    state.rebases = 0;

    updateAircraftFrame();
    updateCamera();
    probeGround();
    updateHud();

    var latEl = $('in-lat'), lonEl = $('in-lon'), altEl = $('in-alt');
    if (latEl) latEl.value = lat.toFixed(4);
    if (lonEl) lonEl.value = lon.toFixed(4);
    if (altEl) altEl.value = alt;

    log('spawn', lon, lat, alt, hdgDeg);
  }

  // ---------------------------------------------------------------
  // 入力
  // ---------------------------------------------------------------
  function setupInput() {
    global.addEventListener('keydown', function (e) {
      var k = e.key.toLowerCase();
      if (k === 'r') { respawn(); return; }
      if (k === 'w' || k === 'a' || k === 's' || k === 'd' || k === 'q' || k === 'e' ||
          k === 'arrowup' || k === 'arrowdown' || k === ' ') {
        keys[k] = true;
        e.preventDefault();
      }
    });
    global.addEventListener('keyup', function (e) {
      var k = e.key.toLowerCase();
      keys[k] = false;
    });
    global.addEventListener('blur', function () {
      keys = Object.create(null);
      drag.pitch = drag.roll = 0;
      drag.active = false;
    });

    // ドラッグ操縦（マウス / タッチ）
    var canvas = viewer.canvas;
    canvas.addEventListener('pointerdown', function (e) {
      if (drag.active) return;
      drag.active = true;
      drag.id = e.pointerId;
      drag.x = e.clientX;
      drag.y = e.clientY;
      try { canvas.setPointerCapture(e.pointerId); } catch (err) {}
    });
    canvas.addEventListener('pointermove', function (e) {
      if (!drag.active || e.pointerId !== drag.id) return;
      var dx = e.clientX - drag.x;
      var dy = e.clientY - drag.y;
      drag.x = e.clientX;
      drag.y = e.clientY;
      // 右へ倒す＝右ロール / 下へ引く＝機首上げ
      drag.roll = clamp(drag.roll + dx * 0.02, -1, 1);
      drag.pitch = clamp(drag.pitch + dy * 0.015, -1, 1);
    });
    var endDrag = function (e) {
      if (drag.id !== null && e.pointerId !== drag.id) return;
      drag.active = false;
      drag.id = null;
      drag.pitch = 0;
      drag.roll = 0;
    };
    canvas.addEventListener('pointerup', endDrag);
    canvas.addEventListener('pointercancel', endDrag);
    canvas.addEventListener('lostpointercapture', endDrag);
  }

  // タッチパッド（推力 +/- / リセット）
  function setupTouchPad() {
    var bind = function (id, onDown, onUp) {
      var el = $(id);
      if (!el) return;
      el.addEventListener('pointerdown', function (e) {
        e.preventDefault();
        try { el.setPointerCapture(e.pointerId); } catch (err) {}
        el.classList.add('pressed');
        onDown();
      });
      var up = function (e) {
        if (e) e.preventDefault();
        el.classList.remove('pressed');
        if (onUp) onUp();
      };
      el.addEventListener('pointerup', up);
      el.addEventListener('pointercancel', up);
      el.addEventListener('lostpointercapture', up);
      el.addEventListener('contextmenu', function (e) { e.preventDefault(); });
    };

    // 押している間ずっと推力を動かす
    bind('tb-thr-up', function () { keys['arrowup'] = true; }, function () { keys['arrowup'] = false; });
    bind('tb-thr-down', function () { keys['arrowdown'] = true; }, function () { keys['arrowdown'] = false; });
    bind('tb-reset', respawn, null);
  }

  function respawn() {
    spawnAt(state.lon, state.lat, Math.max(state.y, 800), C.Math.toDegrees(state.hdg));
    showNotice('リセットしました', true);
  }

  // ---------------------------------------------------------------
  // 設定 UI
  // ---------------------------------------------------------------
  function setupSettings() {
    var settings = $('settings');
    var open = function () {
      var ti = $('token-input');
      if (ti) ti.value = readToken();
      settings.classList.remove('hidden');
    };
    var close = function () { settings.classList.add('hidden'); };

    $('btn-settings').addEventListener('click', open);
    $('btn-close-settings').addEventListener('click', close);
    settings.addEventListener('click', function (e) { if (e.target === settings) close(); });

    $('btn-token-save').addEventListener('click', function () {
      var v = ($('token-input').value || '').trim();
      writeToken(v);
      setLoadingText('地形を読み込み中…', '');
      $('loading').style.display = 'flex';
      $('loading').classList.remove('hidden');
      applyTerrain().then(function () {
        return new Promise(function (res) { setTimeout(res, 800); });
      }).then(function () {
        hideLoading();
        spawnAt(state.lon, state.lat, state.y, C.Math.toDegrees(state.hdg));
        close();
      });
    });

    $('btn-token-clear').addEventListener('click', function () {
      writeToken('');
      $('token-input').value = '';
      applyTerrain();
      showNotice('トークンを削除しました（簡易地形モード）', true);
    });

    // プリセットボタン
    var wrap = $('presets');
    PRESETS.forEach(function (p) {
      var b = document.createElement('button');
      b.className = 'ui-btn';
      b.textContent = p.name;
      b.addEventListener('click', function () {
        spawnAt(p.lon, p.lat, p.alt, p.hdg);
        close();
        showNotice(p.name + ' へ移動しました', true);
      });
      wrap.appendChild(b);
    });

    $('btn-goto').addEventListener('click', function () {
      var lat = parseFloat($('in-lat').value);
      var lon = parseFloat($('in-lon').value);
      var alt = parseFloat($('in-alt').value);
      if (!isFinite(lat) || !isFinite(lon) || !isFinite(alt)) {
        showNotice('緯度・経度・高度を数値で入力してください');
        return;
      }
      if (Math.abs(lat) > 85) { showNotice('極域（±85°以上）は Phase 0 では非対応です'); return; }
      spawnAt(lon, lat, alt, C.Math.toDegrees(state.hdg));
      close();
    });
  }

  // ---------------------------------------------------------------
  // 起動
  // ---------------------------------------------------------------
  function boot() {
    log('boot phase0');
    createViewer();
    buildPlaceholderAircraft();
    updateTerrainBadge();

    setLoadingText('地形を読み込み中…', '');
    applyTerrain().then(function () {
      spawnAt(DEFAULT.lon, DEFAULT.lat, DEFAULT.alt, DEFAULT.hdg);
      setupInput();
      setupTouchPad();
      setupSettings();
      $('btn-settings').style.visibility = 'visible';
      hideLoading();
      lastTime = 0;
      requestAnimationFrame(tick);
      global.__flightSimPhase0.ready = true;
      log('boot ok');
    }).catch(function (err) {
      console.error('[flight-sim] boot failed', err);
      setLoadingText('起動に失敗しました', String(err && err.message || err));
    });
  }

  // テスト・デバッグ用フック
  global.__flightSimPhase0 = {
    ready: false,
    getState: function () { return state; },
    getViewer: function () { return viewer; },
    spawnAt: spawnAt,
    presets: PRESETS
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})(window);
