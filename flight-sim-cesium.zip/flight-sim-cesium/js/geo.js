// 座標変換（グローバル: FlightSimGeo）
// 局所座標（シミュレータの物理座標）と Cesium の ECEF / ENU を橋渡しする。
//
//   シミュレータ座標: x = 右（東）, y = 上, z = 後方（南）   ※前方は -z（北）
//   ENU 座標:         east, north, up
//   → 対応: east = x, north = -z, up = y
(function (global) {
  'use strict';

  var C = global.Cesium;

  // Cesium が読めていない場合は何もしない（オフライン案内は index.html 側が表示する）
  if (!C) return;

  var Geo = {
    originLon: 0,
    originLat: 0,
    originCarto: null,
    originEcef: null,
    enuMat: null,

    _scratchCarto: new C.Cartographic(),
    _scratchVec: new C.Cartesian3(),
    _scratchMat: new C.Matrix4()
  };

  // 原点を設定（ENU フレームを張る）
  Geo.setOrigin = function (lonDeg, latDeg) {
    Geo.originLon = lonDeg;
    Geo.originLat = latDeg;
    Geo.originCarto = C.Cartographic.fromDegrees(lonDeg, latDeg, 0);
    Geo.originEcef = C.Cartographic.toCartesian(Geo.originCarto);
    Geo.enuMat = C.Transforms.eastNorthUpToFixedFrame(Geo.originEcef);
    return Geo.enuMat;
  };

  // 局所座標 → ECEF（原点からの水平オフセット。高度は含めない）
  Geo.offsetToEcef = function (x, z, out) {
    var enu = C.Cartesian3.fromElements(x, -z, 0, Geo._scratchVec);
    return C.Matrix4.multiplyByPoint(Geo.enuMat, enu, out || new C.Cartesian3());
  };

  // 局所座標（x, 高度 y, z）→ ECEF
  Geo.localToEcef = function (x, y, z, out) {
    var enu = C.Cartesian3.fromElements(x, -z, 0, Geo._scratchVec);
    var horizontal = C.Matrix4.multiplyByPoint(Geo.enuMat, enu, out || new C.Cartesian3());
    var carto = C.Cartographic.fromCartesian(horizontal, C.Ellipsoid.WGS84, Geo._scratchCarto);
    carto.height = y;
    return C.Cartographic.toCartesian(carto, C.Ellipsoid.WGS84, horizontal);
  };

  // ECEF → 緯度経度高度
  Geo.ecefToLonLat = function (ecef, result) {
    var carto = C.Cartographic.fromCartesian(ecef, C.Ellipsoid.WGS84, Geo._scratchCarto);
    result = result || {};
    result.lon = C.Math.toDegrees(carto.longitude);
    result.lat = C.Math.toDegrees(carto.latitude);
    result.height = carto.height;
    result.longitude = carto.longitude;
    result.latitude = carto.latitude;
    return result;
  };

  // 緯度経度高度 → ECEF
  Geo.lonLatToEcef = function (lonDeg, latDeg, height, out) {
    var carto = C.Cartographic.fromDegrees(lonDeg, latDeg, height || 0);
    return C.Cartographic.toCartesian(carto, C.Ellipsoid.WGS84, out || new C.Cartesian3());
  };

  // 原点からの東/北オフセット（メートル）を返す（リベース判定用）
  Geo.distanceFromOrigin = function (x, z) {
    return Math.sqrt(x * x + z * z);
  };

  global.FlightSimGeo = Geo;
})(window);
